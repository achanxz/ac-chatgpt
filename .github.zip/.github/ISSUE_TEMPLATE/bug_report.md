---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

- **(1) Describe the bug 简述**


- **(2) Screen Shot 截图**


- **(3) Terminal Traceback 终端traceback（如有）**


- **(4) Material to Help Reproduce Bugs 帮助我们复现的测试材料样本（如有）**



Before submitting an issue 提交issue之前：
- Please try to upgrade your code. 如果您的代码不是最新的，建议您先尝试更新代码
- Please check project wiki for common problem solutions.项目[wiki](https://github.com/binary-husky/chatgpt_academic/wiki)有一些常见问题的解决方法
